"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CheckCircle, Trophy, Users, Calendar, PlusCircle } from "lucide-react"

export default function ChallengesPage() {
  const [newChallengeDialogOpen, setNewChallengeDialogOpen] = useState(false)

  // Mock data for challenges
  const [activeChallenges, setActiveChallenges] = useState([
    {
      id: "1",
      title: "30 Days of Meditation",
      description: "Meditate for at least 10 minutes every day for 30 days",
      category: "Mindfulness",
      duration: "30 days",
      startDate: "April 15, 2025",
      endDate: "May 15, 2025",
      participants: 8,
      progress: 60,
      creator: {
        name: "Sarah Williams",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      members: [
        { name: "Alex J", avatar: "/placeholder.svg?height=40&width=40" },
        { name: "Michael B", avatar: "/placeholder.svg?height=40&width=40" },
        { name: "You", avatar: "/placeholder.svg?height=40&width=40" },
      ],
    },
    {
      id: "2",
      title: "Daily Reading Challenge",
      description: "Read for at least 30 minutes every day",
      category: "Learning",
      duration: "21 days",
      startDate: "April 20, 2025",
      endDate: "May 11, 2025",
      participants: 5,
      progress: 25,
      creator: {
        name: "Alex Johnson",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      members: [
        { name: "Sarah W", avatar: "/placeholder.svg?height=40&width=40" },
        { name: "You", avatar: "/placeholder.svg?height=40&width=40" },
      ],
    },
  ])

  const [availableChallenges, setAvailableChallenges] = useState([
    {
      id: "3",
      title: "Morning Workout Challenge",
      description: "Complete a 15-minute workout every morning before 9 AM",
      category: "Fitness",
      duration: "14 days",
      startDate: "May 1, 2025",
      endDate: "May 15, 2025",
      participants: 12,
      creator: {
        name: "James Wilson",
        avatar: "/placeholder.svg?height=40&width=40",
      },
    },
    {
      id: "4",
      title: "Healthy Eating Week",
      description: "Eat at least 5 servings of vegetables and fruits daily",
      category: "Nutrition",
      duration: "7 days",
      startDate: "April 25, 2025",
      endDate: "May 2, 2025",
      participants: 20,
      creator: {
        name: "Emily Davis",
        avatar: "/placeholder.svg?height=40&width=40",
      },
    },
  ])

  const joinChallenge = (id: string) => {
    const challenge = availableChallenges.find((c) => c.id === id)
    if (challenge) {
      const newChallenge = {
        ...challenge,
        progress: 0,
        members: [{ name: "You", avatar: "/placeholder.svg?height=40&width=40" }],
      }
      setActiveChallenges([...activeChallenges, newChallenge])
      setAvailableChallenges(availableChallenges.filter((c) => c.id !== id))
    }
  }

  const leaveChallenge = (id: string) => {
    setActiveChallenges(activeChallenges.filter((c) => c.id !== id))
  }

  const createChallenge = () => {
    // In a real app, this would create a new challenge with form data
    setNewChallengeDialogOpen(false)
  }

  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="border-b">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-6 w-6 text-emerald-500" />
            <span className="text-xl font-bold">HabitTracker</span>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                Dashboard
              </Button>
            </Link>
            <Link href="/friends">
              <Button variant="ghost" size="sm">
                Friends
              </Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Challenges</h1>
            <p className="text-gray-500">Join challenges with friends to stay motivated</p>
          </div>
          <Dialog open={newChallengeDialogOpen} onOpenChange={setNewChallengeDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-emerald-500 hover:bg-emerald-600">
                <PlusCircle className="mr-2 h-4 w-4" />
                Create Challenge
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create a new challenge</DialogTitle>
                <DialogDescription>
                  Create a challenge and invite friends to join you on your habit journey.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="challenge-title">Challenge title</Label>
                  <Input id="challenge-title" placeholder="e.g., 30 Days of Meditation" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="challenge-description">Description</Label>
                  <Textarea id="challenge-description" placeholder="Describe your challenge and its goals" rows={3} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="challenge-category">Category</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fitness">Fitness</SelectItem>
                      <SelectItem value="learning">Learning</SelectItem>
                      <SelectItem value="nutrition">Nutrition</SelectItem>
                      <SelectItem value="mindfulness">Mindfulness</SelectItem>
                      <SelectItem value="productivity">Productivity</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="start-date">Start date</Label>
                    <Input id="start-date" type="date" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="duration">Duration</Label>
                    <Select defaultValue="30">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="7">7 days</SelectItem>
                        <SelectItem value="14">14 days</SelectItem>
                        <SelectItem value="21">21 days</SelectItem>
                        <SelectItem value="30">30 days</SelectItem>
                        <SelectItem value="60">60 days</SelectItem>
                        <SelectItem value="90">90 days</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="privacy">Privacy</Label>
                  <Select defaultValue="friends">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="public">Public - Anyone can join</SelectItem>
                      <SelectItem value="friends">Friends only</SelectItem>
                      <SelectItem value="invite">Invite only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setNewChallengeDialogOpen(false)}>
                  Cancel
                </Button>
                <Button className="bg-emerald-500 hover:bg-emerald-600" onClick={createChallenge}>
                  Create Challenge
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <Tabs defaultValue="active" className="w-full">
          <TabsList className="mb-8">
            <TabsTrigger value="active">My Challenges</TabsTrigger>
            <TabsTrigger value="discover">Discover</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>

          <TabsContent value="active">
            <div className="grid md:grid-cols-2 gap-6">
              {activeChallenges.map((challenge) => (
                <Card key={challenge.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{challenge.title}</CardTitle>
                        <CardDescription className="mt-1">{challenge.description}</CardDescription>
                      </div>
                      <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100">
                        {challenge.category}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4 text-gray-500" />
                        <span>
                          {challenge.startDate} - {challenge.endDate}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4 text-gray-500" />
                        <span>{challenge.participants} participants</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Your progress</span>
                        <span className="font-medium">{challenge.progress}%</span>
                      </div>
                      <Progress value={challenge.progress} className="h-2" />
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Participants</p>
                      <div className="flex -space-x-2">
                        {challenge.members.map((member, i) => (
                          <Avatar key={i} className="border-2 border-white h-8 w-8">
                            <AvatarImage src={member.avatar || "/placeholder.svg"} alt={member.name} />
                            <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                        ))}
                        {challenge.participants > 3 && (
                          <div className="flex items-center justify-center h-8 w-8 rounded-full bg-gray-100 text-xs font-medium border-2 border-white">
                            +{challenge.participants - 3}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Avatar className="h-6 w-6">
                        <AvatarImage
                          src={challenge.creator.avatar || "/placeholder.svg"}
                          alt={challenge.creator.name}
                        />
                        <AvatarFallback>{challenge.creator.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span>Created by {challenge.creator.name}</span>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => leaveChallenge(challenge.id)}>
                      Leave
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="discover">
            <div className="grid md:grid-cols-2 gap-6">
              {availableChallenges.map((challenge) => (
                <Card key={challenge.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{challenge.title}</CardTitle>
                        <CardDescription className="mt-1">{challenge.description}</CardDescription>
                      </div>
                      <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100">
                        {challenge.category}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4 text-gray-500" />
                        <span>
                          {challenge.startDate} - {challenge.endDate}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4 text-gray-500" />
                        <span>{challenge.participants} participants</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Avatar className="h-6 w-6">
                        <AvatarImage
                          src={challenge.creator.avatar || "/placeholder.svg"}
                          alt={challenge.creator.name}
                        />
                        <AvatarFallback>{challenge.creator.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span>Created by {challenge.creator.name}</span>
                    </div>
                    <Button
                      className="bg-emerald-500 hover:bg-emerald-600"
                      size="sm"
                      onClick={() => joinChallenge(challenge.id)}
                    >
                      Join Challenge
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="completed">
            <div className="text-center py-12">
              <Trophy className="h-12 w-12 text-emerald-500 mx-auto mb-4" />
              <h3 className="text-xl font-medium mb-2">No completed challenges yet</h3>
              <p className="text-gray-500 mb-6">Join a challenge and complete it to see it here</p>
              <Button variant="outline" asChild>
                <Link href="/challenges?tab=discover">Discover Challenges</Link>
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t py-6">
        <div className="container flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
            <CheckCircle className="h-5 w-5 text-emerald-500" />
            <span className="font-bold">HabitTracker</span>
          </div>
          <div className="text-sm text-gray-500">&copy; 2025 Habit Tracker. All rights reserved.</div>
        </div>
      </footer>
    </div>
  )
}
