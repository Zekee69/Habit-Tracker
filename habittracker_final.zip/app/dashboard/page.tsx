"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  CheckCircle,
  PlusCircle,
  BarChart3,
  Settings,
  Home,
  Calendar,
  Award,
  TrendingUp,
  Layers,
  Trash2,
  Pencil,
  Search,
  Download,
} from "lucide-react"
import { HabitChart } from "@/components/habit-chart"
import { HabitGrowthChart } from "@/components/analytics/habit-growth-chart"
import { CompletionRateChart } from "@/components/analytics/completion-rate-chart"
import { StreakDistributionChart } from "@/components/analytics/streak-distribution-chart"
import { ProtectedRoute } from "@/components/protected-route"
import { UserAvatar } from "@/components/user-avatar"
import { useAuth } from "@/contexts/auth-context"
import type { Habit } from "@/types/habit"
import { AchievementCard } from "@/components/achievements/achievement-card"
import { useAchievements } from "@/hooks/use-achievements"
import { AddHabitDialog } from "@/components/add-habit-dialog"
import { EditHabitDialog } from "@/components/edit-habit-dialog"
import { DeleteHabitDialog } from "@/components/delete-habit-dialog"
import { exportHabitsToExcel } from "@/utils/export-to-excel"

export default function DashboardPage() {
  const { user } = useAuth()
  const [newHabitDialogOpen, setNewHabitDialogOpen] = useState(false)
  const [editHabitDialogOpen, setEditHabitDialogOpen] = useState(false)
  const [deleteHabitDialogOpen, setDeleteHabitDialogOpen] = useState(false)
  const [shareModalOpen, setShareModalOpen] = useState(false)
  const [selectedStreak, setSelectedStreak] = useState<{ name: string; count: number } | null>(null)
  const [activeTab, setActiveTab] = useState<"home" | "habits" | "achievements" | "statistics" | "categories">("home")
  const [searchQuery, setSearchQuery] = useState("")

  const [habits, setHabits] = useState<Habit[]>([])
  const [habitHistory, setHabitHistory] = useState<{
    growthData: { month: string; count: number }[]
    previousCompletionRate: number
  }>({
    growthData: [
      { month: "Jan", count: 2 },
      { month: "Feb", count: 3 },
      { month: "Mar", count: 5 },
      { month: "Apr", count: 4 },
      { month: "May", count: 7 },
      { month: "Jun", count: 9 },
    ],
    previousCompletionRate: 65,
  })

  const [editingHabit, setEditingHabit] = useState<Habit | null>(null)
  const [habitToDelete, setHabitToDelete] = useState<Habit | null>(null)

  const { achievements } = useAchievements(habits)

  // Load habits from localStorage on initial render
  useEffect(() => {
    const storedHabits = localStorage.getItem("habits")
    if (storedHabits) {
      setHabits(JSON.parse(storedHabits))
    } else {
      // Set default habits if none exist
      const defaultHabits: Habit[] = [
        {
          id: "1",
          name: "Morning Run",
          category: "Fitness",
          frequency: "daily",
          completed: false,
          streak: 5,
          startTime: "07:00",
          endTime: "08:00",
        },
        {
          id: "2",
          name: "Read 30 minutes",
          category: "Learning",
          frequency: "daily",
          completed: true,
          streak: 12,
          startTime: "21:00",
          endTime: "21:30",
        },
        {
          id: "3",
          name: "Meditate",
          category: "Mindfulness",
          frequency: "weekdays",
          completed: false,
          streak: 3,
          startTime: "06:30",
          endTime: "06:45",
        },
        {
          id: "4",
          name: "Drink 8 glasses of water",
          category: "Nutrition",
          frequency: "daily",
          completed: false,
          streak: 7,
          startTime: "08:00",
          endTime: "20:00",
        },
      ]
      setHabits(defaultHabits)
      localStorage.setItem("habits", JSON.stringify(defaultHabits))
    }
  }, [])

  // Save habits to localStorage whenever they change
  useEffect(() => {
    if (habits.length > 0) {
      localStorage.setItem("habits", JSON.stringify(habits))
    }
  }, [habits])

  const shareStreak = (habitName: string, streakCount: number) => {
    setSelectedStreak({ name: habitName, count: streakCount })
    setShareModalOpen(true)
  }

  const handleAddHabit = (newHabit: Omit<Habit, "id" | "completed" | "streak">) => {
    const newId = (habits.length + 1).toString()
    const habitToAdd: Habit = {
      id: newId,
      name: newHabit.name,
      category: newHabit.category,
      frequency: newHabit.frequency,
      startTime: newHabit.startTime,
      endTime: newHabit.endTime,
      completed: false,
      streak: 0,
    }

    const updatedHabits = [...habits, habitToAdd]
    setHabits(updatedHabits)

    // Update growth data
    const currentMonth = new Date().toLocaleString("default", { month: "short" })
    const updatedGrowthData = [...habitHistory.growthData]
    const lastMonthIndex = updatedGrowthData.findIndex((item) => item.month === currentMonth)

    if (lastMonthIndex !== -1) {
      updatedGrowthData[lastMonthIndex].count += 1
    } else {
      updatedGrowthData.push({ month: currentMonth, count: 1 })
    }

    setHabitHistory({
      ...habitHistory,
      growthData: updatedGrowthData,
    })

    setNewHabitDialogOpen(false)
  }

  const handleEditHabit = (editedHabit: Habit) => {
    if (!editedHabit || !editedHabit.name) return

    setHabits(habits.map((habit) => (habit.id === editedHabit.id ? editedHabit : habit)))
    setEditHabitDialogOpen(false)
  }

  const handleDeleteHabit = () => {
    if (!habitToDelete) return

    setHabits(habits.filter((habit) => habit.id !== habitToDelete.id))
    setDeleteHabitDialogOpen(false)
  }

  const openEditDialog = (habit: Habit) => {
    setEditingHabit(habit)
    setEditHabitDialogOpen(true)
  }

  const openDeleteDialog = (habit: Habit) => {
    setHabitToDelete(habit)
    setDeleteHabitDialogOpen(true)
  }

  const toggleHabitCompletion = (id: string) => {
    setHabits(
      habits.map((habit) => {
        if (habit.id === id) {
          const wasCompleted = habit.completed
          const newStreak = wasCompleted ? habit.streak || 0 : (habit.streak || 0) + 1
          return { ...habit, completed: !wasCompleted, streak: newStreak }
        }
        return habit
      }),
    )
  }

  const handleExportToExcel = () => {
    exportHabitsToExcel(habits)
  }

  // Calculate statistics
  const totalHabits = habits.length
  const completedToday = habits.filter((habit) => habit.completed).length
  const streakCount = Math.max(...habits.map((habit) => habit.streak || 0))
  const completionRate = habits.length > 0 ? Math.round((completedToday / totalHabits) * 100) : 0

  // Calculate percentage change for new habits
  const currentMonthCount = habitHistory.growthData[habitHistory.growthData.length - 1]?.count || 0
  const previousMonthCount = habitHistory.growthData[habitHistory.growthData.length - 2]?.count || 1
  const habitGrowthPercentage = Math.round(((currentMonthCount - previousMonthCount) / previousMonthCount) * 100)

  // Group habits by category
  const habitsByCategory = habits.reduce(
    (acc, habit) => {
      const category = habit.category.toLowerCase()
      if (!acc[category]) {
        acc[category] = 0
      }
      acc[category]++
      return acc
    },
    {} as Record<string, number>,
  )

  // Filter habits based on search query
  const filteredHabits = habits.filter(
    (habit) =>
      habit.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      habit.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Prepare data for streak distribution chart
  const streakDistributionData = habits
    .filter((habit) => (habit.streak || 0) > 0)
    .map((habit) => ({
      habitName: habit.name,
      streak: habit.streak || 0,
    }))

  return (
    <ProtectedRoute>
      <div className="flex min-h-screen bg-gradient-to-br from-purple-200 to-white">
        {/* Sidebar */}
        <div className="w-64 bg-purple-700 text-white min-h-screen">
          <div className="p-4 flex items-center gap-2 border-b border-purple-600">
            <CheckCircle className="h-6 w-6" />
            <span className="text-xl font-bold">HabitTracker</span>
          </div>
          <nav className="p-2">
            <button
              onClick={() => setActiveTab("home")}
              className={`flex w-full items-center gap-3 p-3 rounded-md ${
                activeTab === "home" ? "bg-purple-800" : "hover:bg-purple-600"
              } mb-1`}
            >
              <Home className="h-5 w-5" />
              <span>Home</span>
            </button>
            <button
              onClick={() => setActiveTab("habits")}
              className={`flex w-full items-center gap-3 p-3 rounded-md ${
                activeTab === "habits" ? "bg-purple-800" : "hover:bg-purple-600"
              } mb-1`}
            >
              <Calendar className="h-5 w-5" />
              <span>Habits</span>
            </button>
            <button
              onClick={() => setActiveTab("achievements")}
              className={`flex w-full items-center gap-3 p-3 rounded-md ${
                activeTab === "achievements" ? "bg-purple-800" : "hover:bg-purple-600"
              } mb-1`}
            >
              <Award className="h-5 w-5" />
              <span>Achievements</span>
            </button>
            <button
              onClick={() => setActiveTab("statistics")}
              className={`flex w-full items-center gap-3 p-3 rounded-md ${
                activeTab === "statistics" ? "bg-purple-800" : "hover:bg-purple-600"
              } mb-1`}
            >
              <TrendingUp className="h-5 w-5" />
              <span>Statistics</span>
            </button>
            <button
              onClick={() => setActiveTab("categories")}
              className={`flex w-full items-center gap-3 p-3 rounded-md ${
                activeTab === "categories" ? "bg-purple-800" : "hover:bg-purple-600"
              } mb-1`}
            >
              <Layers className="h-5 w-5" />
              <span>Categories</span>
            </button>
            <Link href="/profile" className="flex items-center gap-3 p-3 rounded-md hover:bg-purple-600 mb-1">
              <Settings className="h-5 w-5" />
              <span>Profile</span>
            </Link>
          </nav>
          <div className="mt-auto p-4 border-t border-purple-600">
            <button
              onClick={() => setNewHabitDialogOpen(true)}
              className="flex w-full items-center gap-3 p-3 rounded-md hover:bg-purple-600 mb-1"
            >
              <PlusCircle className="h-5 w-5" />
              <span>Add Habit</span>
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6">
          {/* Header */}
          <header className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-2xl font-bold">
                {activeTab === "home" ? "Dashboard" : activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
              </h1>
              <p className="text-gray-500">Welcome back, {user?.name}! Here's your habit overview</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  className="pl-10 w-64"
                  placeholder="Search habits..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <UserAvatar />
            </div>
          </header>

          {/* Tab Content */}
          {activeTab === "home" && (
            <>
              {/* Stats Cards */}
              <div className="grid grid-cols-4 gap-6 mb-8">
                <Card className="border border-purple-100">
                  <CardContent className="p-6">
                    <div className="text-3xl font-bold text-purple-700">{totalHabits}</div>
                    <div className="text-sm text-gray-500 mt-1">Total Habits</div>
                  </CardContent>
                </Card>
                <Card className="border border-purple-100">
                  <CardContent className="p-6">
                    <div className="text-3xl font-bold text-purple-700">{completedToday}</div>
                    <div className="text-sm text-gray-500 mt-1">Completed Today</div>
                  </CardContent>
                </Card>
                <Card className="border border-purple-100">
                  <CardContent className="p-6">
                    <div className="text-3xl font-bold text-purple-700">{streakCount}</div>
                    <div className="text-sm text-gray-500 mt-1">Longest Streak</div>
                  </CardContent>
                </Card>
                <Card className="border border-purple-100">
                  <CardContent className="p-6">
                    <div className="text-3xl font-bold text-purple-700">{completionRate}%</div>
                    <div className="text-sm text-gray-500 mt-1">Completion Rate</div>
                  </CardContent>
                </Card>
              </div>

              {/* Main Content Grid */}
              <div className="grid grid-cols-3 gap-6">
                {/* Today's Habits */}
                <Card className="col-span-2 border border-purple-100">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Calendar className="mr-2 h-5 w-5 text-purple-500" />
                        Today's Habits
                      </div>
                      <Button
                        size="sm"
                        className="bg-purple-500 hover:bg-purple-600 text-white"
                        onClick={() => setNewHabitDialogOpen(true)}
                      >
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Add Habit
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {filteredHabits.length === 0 ? (
                        <div className="text-center py-8 text-gray-500">
                          {searchQuery ? "No habits match your search" : "No habits added yet"}
                        </div>
                      ) : (
                        filteredHabits.map((habit) => (
                          <div
                            key={habit.id}
                            className={`flex items-center justify-between p-4 border rounded-lg ${
                              habit.completed ? "bg-purple-50 border-purple-200" : "bg-white"
                            }`}
                          >
                            <div>
                              <h3 className="font-medium">{habit.name}</h3>
                              <div className="flex items-center gap-2">
                                <p className="text-sm text-gray-500">{habit.category}</p>
                                {(habit.startTime || habit.endTime) && (
                                  <span className="text-xs font-medium text-blue-500 bg-blue-50 px-2 py-1 rounded">
                                    {habit.startTime && habit.endTime
                                      ? `${habit.startTime} - ${habit.endTime}`
                                      : habit.startTime
                                        ? `${habit.startTime}`
                                        : `Until ${habit.endTime}`}
                                  </span>
                                )}
                                {habit.streak && habit.streak > 0 && (
                                  <span className="text-xs font-medium text-purple-500">{habit.streak} day streak</span>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                variant={habit.completed ? "default" : "outline"}
                                size="sm"
                                className={habit.completed ? "bg-purple-500 hover:bg-purple-600" : ""}
                                onClick={() => toggleHabitCompletion(habit.id)}
                              >
                                <CheckCircle className="h-4 w-4 mr-2" />
                                {habit.completed ? "Completed" : "Mark Complete"}
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="border-gray-200 text-gray-500 hover:bg-gray-50"
                                onClick={() => openEditDialog(habit)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="border-red-200 text-red-500 hover:bg-red-50"
                                onClick={() => openDeleteDialog(habit)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Categories */}
                <Card className="border border-purple-100">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Layers className="mr-2 h-5 w-5 text-purple-500" />
                        Categories
                      </div>
                      <Button variant="link" className="text-purple-500 p-0" onClick={() => setActiveTab("categories")}>
                        View All
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {Object.keys(habitsByCategory).length === 0 ? (
                      <div className="text-center py-8 text-gray-500">No categories yet</div>
                    ) : (
                      <div className="grid grid-cols-2 gap-4">
                        {Object.entries(habitsByCategory).map(([category, count]) => (
                          <div key={category} className="p-4 bg-purple-50 rounded-lg text-center">
                            <div className="text-xl font-bold text-purple-700">{count}</div>
                            <div className="text-sm text-gray-500 capitalize">{category}</div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Progress Chart */}
                <Card className="col-span-3 border border-purple-100">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center">
                      <BarChart3 className="mr-2 h-5 w-5 text-purple-500" />
                      Progress Overview
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <HabitChart />
                  </CardContent>
                </Card>

                {/* Analytics Charts */}
                <Card className="col-span-3 border border-purple-100">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center">
                        <TrendingUp className="mr-2 h-5 w-5 text-purple-500" />
                        Advanced Analytics
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex items-center gap-2"
                        onClick={handleExportToExcel}
                      >
                        <Download className="h-4 w-4" />
                        Export to Excel
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <HabitGrowthChart data={habitHistory.growthData} percentageChange={habitGrowthPercentage} />
                      <CompletionRateChart
                        completedPercentage={completionRate}
                        previousPercentage={habitHistory.previousCompletionRate}
                      />
                      <StreakDistributionChart data={streakDistributionData} />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}

          {activeTab === "habits" && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">All Habits</h2>
                <div className="flex items-center gap-2">
                  <Button variant="outline" className="flex items-center gap-2" onClick={handleExportToExcel}>
                    <Download className="h-4 w-4" />
                    Export to Excel
                  </Button>
                  <Button
                    className="bg-purple-500 hover:bg-purple-600 text-white"
                    onClick={() => setNewHabitDialogOpen(true)}
                  >
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Add Habit
                  </Button>
                </div>
              </div>
              <Card className="border border-purple-100">
                <CardContent className="p-6">
                  {filteredHabits.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      {searchQuery ? "No habits match your search" : "No habits added yet"}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredHabits.map((habit) => (
                        <div
                          key={habit.id}
                          className="flex items-center justify-between p-4 border rounded-lg bg-white"
                        >
                          <div>
                            <h3 className="font-medium">{habit.name}</h3>
                            <div className="flex items-center gap-2">
                              <p className="text-sm text-gray-500">
                                {habit.category} • {habit.frequency}
                                {(habit.startTime || habit.endTime) &&
                                  ` • ${
                                    habit.startTime && habit.endTime
                                      ? `${habit.startTime} - ${habit.endTime}`
                                      : habit.startTime
                                        ? `${habit.startTime}`
                                        : `Until ${habit.endTime}`
                                  }`}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-purple-500">
                              {habit.streak} day{habit.streak !== 1 ? "s" : ""} streak
                            </span>
                            <Button
                              variant={habit.completed ? "default" : "outline"}
                              size="sm"
                              className={habit.completed ? "bg-purple-500 hover:bg-purple-600" : ""}
                              onClick={() => toggleHabitCompletion(habit.id)}
                            >
                              <CheckCircle className="h-4 w-4 mr-2" />
                              {habit.completed ? "Completed" : "Mark Complete"}
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="border-gray-200 text-gray-500 hover:bg-gray-50"
                              onClick={() => openEditDialog(habit)}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="border-red-200 text-red-500 hover:bg-red-50"
                              onClick={() => openDeleteDialog(habit)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "statistics" && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Detailed Statistics</h2>
                <Button variant="outline" className="flex items-center gap-2" onClick={handleExportToExcel}>
                  <Download className="h-4 w-4" />
                  Export to Excel
                </Button>
              </div>
              <Card className="border border-purple-100">
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <Card>
                      <CardContent className="pt-6">
                        <h3 className="font-medium mb-2">Weekly Completion Rate</h3>
                        <div className="text-3xl font-bold text-purple-500">{completionRate}%</div>
                        <p className="text-sm text-gray-500 mt-1">
                          {completionRate > habitHistory.previousCompletionRate ? "+" : ""}
                          {(completionRate - habitHistory.previousCompletionRate).toFixed(1)}% from last week
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <h3 className="font-medium mb-2">Monthly Habit Growth</h3>
                        <div className="text-3xl font-bold text-purple-500">
                          {habitHistory.growthData[habitHistory.growthData.length - 1]?.count || 0}
                        </div>
                        <p className="text-sm text-gray-500 mt-1">
                          {habitGrowthPercentage >= 0 ? "+" : ""}
                          {habitGrowthPercentage}% from last month
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <h3 className="font-medium mb-2">Current Streak</h3>
                        <div className="text-3xl font-bold text-purple-500">{streakCount} days</div>
                        <p className="text-sm text-gray-500 mt-1">
                          {habits.find((h) => (h.streak || 0) === streakCount)?.name || "No active streak"}
                        </p>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <HabitGrowthChart data={habitHistory.growthData} percentageChange={habitGrowthPercentage} />
                    <CompletionRateChart
                      completedPercentage={completionRate}
                      previousPercentage={habitHistory.previousCompletionRate}
                    />
                    <StreakDistributionChart data={streakDistributionData} />
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle>Habit Completion Breakdown</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {Object.entries(habitsByCategory).map(([category, count]) => (
                            <div key={category} className="flex items-center justify-between">
                              <span className="capitalize">{category}</span>
                              <div className="flex items-center gap-2">
                                <div className="w-48 h-2 bg-gray-200 rounded-full overflow-hidden">
                                  <div
                                    className="h-full bg-purple-500 rounded-full"
                                    style={{
                                      width: `${(count / totalHabits) * 100}%`,
                                    }}
                                  ></div>
                                </div>
                                <span className="text-sm font-medium">{Math.round((count / totalHabits) * 100)}%</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "achievements" && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Achievements</h2>
                <div className="text-sm text-gray-500">
                  {achievements.filter((a) => a.earned).length} of {achievements.length} earned
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {achievements.map((achievement) => (
                  <AchievementCard key={achievement.id} achievement={achievement} />
                ))}
              </div>
            </div>
          )}

          {activeTab === "categories" && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Categories</h2>
                <Button
                  className="bg-purple-500 hover:bg-purple-600 text-white"
                  onClick={() => setNewHabitDialogOpen(true)}
                >
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Add Habit
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Object.keys(habitsByCategory).length === 0 ? (
                  <Card className="col-span-full border border-purple-100">
                    <CardContent className="p-6 text-center">
                      <p className="text-gray-500">No habits added yet. Add your first habit to get started!</p>
                    </CardContent>
                  </Card>
                ) : (
                  Object.entries(habitsByCategory).map(([category, count]) => (
                    <Card key={category} className="border border-purple-100">
                      <CardHeader className="pb-3">
                        <CardTitle className="capitalize">{category}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex justify-between items-center mb-4">
                          <span className="text-2xl font-bold text-purple-700">{count}</span>
                          <span className="text-sm text-gray-500">habits</span>
                        </div>
                        <div className="space-y-2">
                          {habits
                            .filter((habit) => habit.category.toLowerCase() === category.toLowerCase())
                            .map((habit) => (
                              <div
                                key={habit.id}
                                className="p-3 border rounded-lg bg-white flex justify-between items-center"
                              >
                                <div>
                                  <h3 className="font-medium">{habit.name}</h3>
                                  <div className="flex items-center gap-1">
                                    <p className="text-xs text-gray-500">{habit.frequency}</p>
                                    {(habit.startTime || habit.endTime) && (
                                      <span className="text-xs text-blue-500">
                                        •{" "}
                                        {habit.startTime && habit.endTime
                                          ? `${habit.startTime}-${habit.endTime}`
                                          : habit.startTime
                                            ? habit.startTime
                                            : `Until ${habit.endTime}`}
                                      </span>
                                    )}
                                  </div>
                                </div>
                                <Button
                                  variant={habit.completed ? "default" : "outline"}
                                  size="sm"
                                  className={habit.completed ? "bg-purple-500 hover:bg-purple-600" : ""}
                                  onClick={() => toggleHabitCompletion(habit.id)}
                                >
                                  {habit.completed ? "Completed" : "Complete"}
                                </Button>
                              </div>
                            ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Dialogs */}
      <AddHabitDialog open={newHabitDialogOpen} onOpenChange={setNewHabitDialogOpen} onAddHabit={handleAddHabit} />

      <EditHabitDialog
        open={editHabitDialogOpen}
        onOpenChange={setEditHabitDialogOpen}
        habit={editingHabit}
        onEditHabit={handleEditHabit}
      />

      <DeleteHabitDialog
        open={deleteHabitDialogOpen}
        onOpenChange={setDeleteHabitDialogOpen}
        habit={habitToDelete}
        onDeleteHabit={handleDeleteHabit}
      />
    </ProtectedRoute>
  )
}
