"use client"

import { AvatarUploadTest } from "@/components/test/avatar-upload-test"
import { ProtectedRoute } from "@/components/protected-route"

export default function TestAvatarPage() {
  return (
    <ProtectedRoute>
      <div className="container mx-auto py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold">Avatar Upload Testing</h1>
            <p className="text-gray-600 mt-2">
              Test the profile picture upload functionality with different file formats and sizes.
            </p>
          </div>
          <AvatarUploadTest />
        </div>
      </div>
    </ProtectedRoute>
  )
}
