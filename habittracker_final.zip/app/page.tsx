import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, BarChart3, CheckCircle, Shield } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Navigation */}
      <header className="border-b">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-6 w-6 text-purple-500" />
            <span className="text-xl font-bold">HabitTracker</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#features" className="text-sm font-medium hover:text-purple-500 transition-colors">
              Features
            </Link>
            <Link href="#examples" className="text-sm font-medium hover:text-purple-500 transition-colors">
              Examples
            </Link>
            <Link href="#about" className="text-sm font-medium hover:text-purple-500 transition-colors">
              About
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="outline">Log in</Button>
            </Link>
            <Link href="/signup">
              <Button className="bg-purple-500 hover:bg-purple-600">Sign up</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-b from-white to-purple-50">
        <div className="container flex flex-col items-center text-center">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6">
            Build better habits, <span className="text-purple-500">one day at a time</span>
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mb-10">
            Track your daily habits, visualize your progress, and achieve your personal goals with our simple yet
            powerful habit tracking tool.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/signup">
              <Button size="lg" className="bg-purple-500 hover:bg-purple-600">
                Get Started <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">Key Features</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-white shadow-sm">
              <div className="p-3 rounded-full bg-purple-100 mb-4">
                <CheckCircle className="h-6 w-6 text-purple-500" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Daily Habit Logging</h3>
              <p className="text-gray-600">
                Easily log your daily habits with a simple interface. Mark habits as completed or missed with a single
                click.
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-white shadow-sm">
              <div className="p-3 rounded-full bg-purple-100 mb-4">
                <BarChart3 className="h-6 w-6 text-purple-500" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Progress Visualization</h3>
              <p className="text-gray-600">
                Track your progress with beautiful charts and graphs. See your habit streaks and identify patterns.
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-white shadow-sm">
              <div className="p-3 rounded-full bg-purple-100 mb-4">
                <Shield className="h-6 w-6 text-purple-500" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Secure Authentication</h3>
              <p className="text-gray-600">
                Your data is protected with secure login and registration. Create a personalized account for private
                habit tracking.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Examples Section */}
      <section id="examples" className="py-20 bg-purple-50">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">Daily Life Examples</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg border shadow-sm">
              <h3 className="text-xl font-semibold mb-4">Fitness Goals</h3>
              <p className="text-gray-600 mb-4">
                Track your exercise routines, such as running or yoga, helping you stay committed to your fitness
                journey.
              </p>
              <div className="bg-gray-100 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Morning Run</span>
                  <span className="text-purple-500 font-medium">5/7 days</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-purple-500 h-2.5 rounded-full" style={{ width: "71%" }}></div>
                </div>
              </div>
            </div>
            <div className="bg-white p-6 rounded-lg border shadow-sm">
              <h3 className="text-xl font-semibold mb-4">Reading Habits</h3>
              <p className="text-gray-600 mb-4">
                Logging daily reading sessions can encourage you to allocate time for personal development and learning.
              </p>
              <div className="bg-gray-100 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Read 30 minutes</span>
                  <span className="text-purple-500 font-medium">12 day streak</span>
                </div>
                <div className="flex gap-1 mt-2">
                  {Array(12)
                    .fill(0)
                    .map((_, i) => (
                      <div key={i} className="w-6 h-6 rounded-sm bg-purple-500"></div>
                    ))}
                  <div className="w-6 h-6 rounded-sm bg-gray-200"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20">
        <div className="container text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold mb-6">About Habit Tracker</h2>
          <p className="text-gray-600 mb-8">
            The Habit Tracker is designed to help individuals cultivate positive habits and eliminate negative ones. In
            today's fast-paced world, maintaining good habits can be challenging, leading to stress, decreased
            productivity, and overall dissatisfaction. Our application addresses these challenges by providing a simple
            yet effective tool to monitor daily actions and progress.
          </p>
          <div className="flex justify-center">
            <Link href="/signup">
              <Button size="lg" className="bg-purple-500 hover:bg-purple-600">
                Start Your Journey Today
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 border-t mt-auto">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <CheckCircle className="h-5 w-5 text-purple-500" />
              <span className="font-bold">HabitTracker</span>
            </div>
            <div className="text-sm text-gray-500">&copy; 2025 Habit Tracker. All rights reserved.</div>
          </div>
        </div>
      </footer>
    </div>
  )
}
