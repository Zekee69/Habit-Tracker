"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CheckCircle, Award, Share2, Lock, UserCircle } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { AvatarUpload } from "@/components/profile/avatar-upload"
import { toast } from "@/components/ui/use-toast"

export default function ProfilePage() {
  const { user, updateUserProfile } = useAuth()

  // Form state
  const [formData, setFormData] = useState({
    name: user?.name || "",
    username: user?.username || "",
    email: user?.email || "",
    bio: user?.bio || "",
    timezone: "utc-8",
  })

  // Privacy settings
  const [privacySettings, setPrivacySettings] = useState({
    showStreak: true,
    showActivity: true,
    showInDiscovery: true,
  })

  const togglePrivacySetting = (setting: keyof typeof privacySettings) => {
    setPrivacySettings({
      ...privacySettings,
      [setting]: !privacySettings[setting],
    })
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target
    setFormData((prev) => ({ ...prev, [id]: value }))
  }

  const handleSaveProfile = async () => {
    try {
      await updateUserProfile({
        name: formData.name,
        username: formData.username,
        bio: formData.bio,
      })

      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully.",
      })
    } catch (error) {
      toast({
        title: "Update failed",
        description: "There was a problem updating your profile.",
        variant: "destructive",
      })
    }
  }

  // Mock data for achievements
  const achievements = [
    {
      id: "1",
      title: "Early Bird",
      description: "Complete a habit before 8 AM for 5 consecutive days",
      date: "April 10, 2025",
    },
    {
      id: "2",
      title: "Consistency King",
      description: "Maintain a 10-day streak",
      date: "April 18, 2025",
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="border-b">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-6 w-6 text-purple-500" />
            <span className="text-xl font-bold">HabitTracker</span>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                Dashboard
              </Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container py-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Profile Sidebar */}
          <div className="md:w-1/3">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <AvatarUpload />
                  <h2 className="text-2xl font-bold mt-4">{user?.name}</h2>
                  <p className="text-gray-500">@{user?.username || user?.name?.toLowerCase().replace(/\s+/g, "")}</p>
                  <p className="text-sm text-gray-500 mt-1">
                    Member since {new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" })}
                  </p>
                  <p className="mt-4 text-gray-700">{user?.bio || "No bio yet"}</p>

                  <div className="grid grid-cols-2 gap-4 w-full mt-6">
                    <div className="p-4 bg-purple-50 rounded-lg text-center">
                      <div className="text-2xl font-bold text-purple-700">{user?.streakCount || 0}</div>
                      <div className="text-sm text-gray-500">Day Streak</div>
                    </div>
                    <div className="p-4 bg-purple-50 rounded-lg text-center">
                      <div className="text-2xl font-bold text-purple-700">{user?.completedHabits || 0}</div>
                      <div className="text-sm text-gray-500">Completed</div>
                    </div>
                  </div>

                  <div className="flex gap-2 mt-6 w-full">
                    <Button className="flex-1 bg-purple-500 hover:bg-purple-600">
                      <Share2 className="mr-2 h-4 w-4" />
                      Share Profile
                    </Button>
                    <Button variant="outline" className="flex-1">
                      <Award className="mr-2 h-4 w-4" />
                      Achievements
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-lg">Recent Achievements</CardTitle>
              </CardHeader>
              <CardContent>
                {achievements.length > 0 ? (
                  <div className="space-y-4">
                    {achievements.map((achievement) => (
                      <div key={achievement.id} className="flex items-start gap-3">
                        <div className="p-2 rounded-full bg-purple-100 text-purple-500">
                          <Award className="h-4 w-4" />
                        </div>
                        <div>
                          <h3 className="font-medium">{achievement.title}</h3>
                          <p className="text-xs text-gray-500">{achievement.description}</p>
                          <p className="text-xs text-gray-400 mt-1">Earned on {achievement.date}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-center py-4">No achievements yet</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Settings Tabs */}
          <div className="md:w-2/3">
            <Tabs defaultValue="account">
              <TabsList className="grid grid-cols-2 mb-6">
                <TabsTrigger value="account" className="flex items-center gap-2">
                  <UserCircle className="h-4 w-4" />
                  Account
                </TabsTrigger>
                <TabsTrigger value="privacy" className="flex items-center gap-2">
                  <Lock className="h-4 w-4" />
                  Privacy
                </TabsTrigger>
              </TabsList>

              <TabsContent value="account">
                <Card>
                  <CardHeader>
                    <CardTitle>Account Settings</CardTitle>
                    <CardDescription>Update your account information and profile details.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form
                      className="space-y-6"
                      onSubmit={(e) => {
                        e.preventDefault()
                        handleSaveProfile()
                      }}
                    >
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">Full Name</Label>
                          <Input id="name" value={formData.name} onChange={handleInputChange} />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="username">Username</Label>
                          <Input id="username" value={formData.username} onChange={handleInputChange} />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" value={formData.email} disabled />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="bio">Bio</Label>
                        <Textarea id="bio" value={formData.bio} onChange={handleInputChange} />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="timezone">Timezone</Label>
                        <Select
                          defaultValue={formData.timezone}
                          onValueChange={(value) => setFormData((prev) => ({ ...prev, timezone: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select timezone" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="utc-8">Pacific Time (UTC-8)</SelectItem>
                            <SelectItem value="utc-5">Eastern Time (UTC-5)</SelectItem>
                            <SelectItem value="utc+0">Greenwich Mean Time (UTC+0)</SelectItem>
                            <SelectItem value="utc+1">Central European Time (UTC+1)</SelectItem>
                            <SelectItem value="utc+8">China Standard Time (UTC+8)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <Button type="submit" className="bg-purple-500 hover:bg-purple-600">
                        Save Changes
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="privacy">
                <Card>
                  <CardHeader>
                    <CardTitle>Privacy Settings</CardTitle>
                    <CardDescription>Manage your privacy preferences and what others can see.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Show Streak Count</h3>
                          <p className="text-sm text-gray-500">Allow others to see your current streak</p>
                        </div>
                        <Switch
                          checked={privacySettings.showStreak}
                          onCheckedChange={() => togglePrivacySetting("showStreak")}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Show Activity</h3>
                          <p className="text-sm text-gray-500">Allow others to see your recent activity</p>
                        </div>
                        <Switch
                          checked={privacySettings.showActivity}
                          onCheckedChange={() => togglePrivacySetting("showActivity")}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Show in Discovery</h3>
                          <p className="text-sm text-gray-500">Allow your profile to appear in discovery</p>
                        </div>
                        <Switch
                          checked={privacySettings.showInDiscovery}
                          onCheckedChange={() => togglePrivacySetting("showInDiscovery")}
                        />
                      </div>

                      <Button className="bg-purple-500 hover:bg-purple-600">Save Privacy Settings</Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  )
}
