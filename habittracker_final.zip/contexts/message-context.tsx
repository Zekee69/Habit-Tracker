"use client"

import type React from "react"

import { createContext, useContext } from "react"
import {
  collection,
  addDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
  doc,
  getDoc,
  updateDoc,
  getDocs,
} from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth, type User } from "./auth-context"

export type Message = {
  id: string
  senderId: string
  receiverId: string
  text: string
  createdAt: any
  read: boolean
}

export type Conversation = {
  id: string
  participantId: string
  participantName: string
  participantAvatar?: string
  lastMessage?: string
  lastMessageDate?: any
  unreadCount: number
}

type MessageContextType = {
  sendMessage: (receiverId: string, text: string) => Promise<void>
  getMessages: (userId: string) => Promise<Message[]>
  markMessagesAsRead: (userId: string) => Promise<void>
  getConversations: () => Promise<Conversation[]>
  listenToMessages: (userId: string, callback: (messages: Message[]) => void) => () => void
  listenToConversations: (callback: (conversations: Conversation[]) => void) => () => void
}

const MessageContext = createContext<MessageContextType | undefined>(undefined)

export function MessageProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth()

  // Send a message
  const sendMessage = async (receiverId: string, text: string) => {
    if (!user) return

    try {
      // Add message to Firestore
      await addDoc(collection(db, "messages"), {
        senderId: user.id,
        receiverId,
        text,
        createdAt: serverTimestamp(),
        read: false,
      })
    } catch (error) {
      console.error("Error sending message:", error)
      throw error
    }
  }

  // Get messages between current user and another user
  const getMessages = async (userId: string): Promise<Message[]> => {
    if (!user) return []

    try {
      // Query messages where current user is sender or receiver
      const messagesRef = collection(db, "messages")
      const q = query(
        messagesRef,
        where("senderId", "in", [user.id, userId]),
        where("receiverId", "in", [user.id, userId]),
        orderBy("createdAt", "asc"),
      )

      const querySnapshot = await getDocs(q)

      const messages: Message[] = []
      querySnapshot.forEach((doc) => {
        const data = doc.data()
        messages.push({
          id: doc.id,
          senderId: data.senderId,
          receiverId: data.receiverId,
          text: data.text,
          createdAt: data.createdAt,
          read: data.read,
        })
      })

      return messages
    } catch (error) {
      console.error("Error getting messages:", error)
      return []
    }
  }

  // Mark messages as read
  const markMessagesAsRead = async (userId: string) => {
    if (!user) return

    try {
      // Find all unread messages from the other user to current user
      const messagesRef = collection(db, "messages")
      const q = query(
        messagesRef,
        where("senderId", "==", userId),
        where("receiverId", "==", user.id),
        where("read", "==", false),
      )

      const querySnapshot = await getDocs(q)

      // Update each message
      const updatePromises: Promise<void>[] = []
      querySnapshot.forEach((document) => {
        updatePromises.push(updateDoc(doc(db, "messages", document.id), { read: true }))
      })

      await Promise.all(updatePromises)
    } catch (error) {
      console.error("Error marking messages as read:", error)
      throw error
    }
  }

  // Get all conversations for the current user
  const getConversations = async (): Promise<Conversation[]> => {
    if (!user) return []

    try {
      // Get all messages where current user is sender or receiver
      const messagesRef = collection(db, "messages")
      const sentQuery = query(messagesRef, where("senderId", "==", user.id), orderBy("createdAt", "desc"))

      const receivedQuery = query(messagesRef, where("receiverId", "==", user.id), orderBy("createdAt", "desc"))

      const [sentSnapshot, receivedSnapshot] = await Promise.all([getDocs(sentQuery), getDocs(receivedQuery)])

      // Combine and process messages to get unique conversations
      const conversationsMap = new Map<string, Conversation>()

      // Process sent messages
      for (const document of sentSnapshot.docs) {
        const message = document.data()
        const otherUserId = message.receiverId

        if (!conversationsMap.has(otherUserId)) {
          // Get user info
          const userDoc = await getDoc(doc(db, "users", otherUserId))
          const userData = userDoc.data() as User

          conversationsMap.set(otherUserId, {
            id: otherUserId,
            participantId: otherUserId,
            participantName: userData?.name || "Unknown User",
            participantAvatar: userData?.avatar,
            lastMessage: message.text,
            lastMessageDate: message.createdAt,
            unreadCount: 0, // Sent by current user, so already read
          })
        }
      }

      // Process received messages
      for (const document of receivedSnapshot.docs) {
        const message = document.data()
        const otherUserId = message.senderId

        if (!conversationsMap.has(otherUserId)) {
          // Get user info
          const userDoc = await getDoc(doc(db, "users", otherUserId))
          const userData = userDoc.data() as User

          conversationsMap.set(otherUserId, {
            id: otherUserId,
            participantId: otherUserId,
            participantName: userData?.name || "Unknown User",
            participantAvatar: userData?.avatar,
            lastMessage: message.text,
            lastMessageDate: message.createdAt,
            unreadCount: message.read ? 0 : 1,
          })
        } else if (!message.read) {
          // Update unread count for existing conversation
          const conversation = conversationsMap.get(otherUserId)!
          conversation.unreadCount += 1

          // Update last message if this is more recent
          if (
            !conversation.lastMessageDate ||
            (message.createdAt && message.createdAt.toMillis() > conversation.lastMessageDate.toMillis())
          ) {
            conversation.lastMessage = message.text
            conversation.lastMessageDate = message.createdAt
          }
        }
      }

      // Convert map to array and sort by last message date
      return Array.from(conversationsMap.values()).sort((a, b) => {
        if (!a.lastMessageDate) return 1
        if (!b.lastMessageDate) return -1
        return b.lastMessageDate.toMillis() - a.lastMessageDate.toMillis()
      })
    } catch (error) {
      console.error("Error getting conversations:", error)
      return []
    }
  }

  // Listen to messages between current user and another user
  const listenToMessages = (userId: string, callback: (messages: Message[]) => void) => {
    if (!user) return () => {}

    // Query messages where current user is sender or receiver
    const messagesRef = collection(db, "messages")
    const q = query(
      messagesRef,
      where("senderId", "in", [user.id, userId]),
      where("receiverId", "in", [user.id, userId]),
      orderBy("createdAt", "asc"),
    )

    // Set up real-time listener
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const messages: Message[] = []
      querySnapshot.forEach((doc) => {
        const data = doc.data()
        messages.push({
          id: doc.id,
          senderId: data.senderId,
          receiverId: data.receiverId,
          text: data.text,
          createdAt: data.createdAt,
          read: data.read,
        })
      })

      callback(messages)
    })

    return unsubscribe
  }

  // Listen to all conversations for the current user
  const listenToConversations = (callback: (conversations: Conversation[]) => void) => {
    if (!user) return () => {}

    // Get all messages where current user is sender or receiver
    const messagesRef = collection(db, "messages")
    const q = query(
      messagesRef,
      where("senderId", "==", user.id),
      where("receiverId", "==", user.id),
      orderBy("createdAt", "desc"),
    )

    // Set up real-time listener
    const unsubscribe = onSnapshot(q, async () => {
      // Get updated conversations
      const conversations = await getConversations()
      callback(conversations)
    })

    return unsubscribe
  }

  return (
    <MessageContext.Provider
      value={{
        sendMessage,
        getMessages,
        markMessagesAsRead,
        getConversations,
        listenToMessages,
        listenToConversations,
      }}
    >
      {children}
    </MessageContext.Provider>
  )
}

export function useMessages() {
  const context = useContext(MessageContext)
  if (context === undefined) {
    throw new Error("useMessages must be used within a MessageProvider")
  }
  return context
}
