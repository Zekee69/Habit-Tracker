"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  type User as FirebaseUser,
} from "firebase/auth"
import { doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore"
import { auth, db } from "@/lib/firebase"

export type User = {
  id: string
  name: string
  email: string | null
  username?: string
  avatar?: string
  bio?: string
  streakCount?: number
  completedHabits?: number
  createdAt?: string
}

type AuthContextType = {
  user: User | null
  isLoading: boolean
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<void>
  signup: (name: string, email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  updateUserProfile: (data: Partial<User>) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  // Listen for auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setIsLoading(true)

      if (firebaseUser) {
        // User is signed in
        const userData = await getUserData(firebaseUser)
        setUser(userData)
      } else {
        // User is signed out
        setUser(null)
      }

      setIsLoading(false)
    })

    return () => unsubscribe()
  }, [])

  // Get additional user data from Firestore
  const getUserData = async (firebaseUser: FirebaseUser): Promise<User> => {
    try {
      const userDocRef = doc(db, "users", firebaseUser.uid)
      const userDoc = await getDoc(userDocRef)

      if (userDoc.exists()) {
        const userData = userDoc.data() as Omit<User, "id">
        return {
          id: firebaseUser.uid,
          name: userData.name || firebaseUser.displayName || "User",
          email: firebaseUser.email,
          username: userData.username,
          avatar: userData.avatar || firebaseUser.photoURL || undefined,
          bio: userData.bio,
          streakCount: userData.streakCount || 0,
          completedHabits: userData.completedHabits || 0,
          createdAt: userData.createdAt,
        }
      }

      return {
        id: firebaseUser.uid,
        name: firebaseUser.displayName || "User",
        email: firebaseUser.email,
        avatar: firebaseUser.photoURL || undefined,
      }
    } catch (error) {
      console.error("Error fetching user data:", error)
      return {
        id: firebaseUser.uid,
        name: firebaseUser.displayName || "User",
        email: firebaseUser.email,
        avatar: firebaseUser.photoURL || undefined,
      }
    }
  }

  // Login function
  const login = async (email: string, password: string) => {
    setIsLoading(true)
    try {
      // Sign in with Firebase
      const userCredential = await signInWithEmailAndPassword(auth, email, password)

      // Get user data and update state immediately
      const userData = await getUserData(userCredential.user)
      setUser(userData)

      // Set loading to false before navigation
      setIsLoading(false)

      // Navigate to dashboard
      router.push("/dashboard")
    } catch (error) {
      setIsLoading(false)
      console.error("Login failed:", error)
      throw error
    }
  }

  // Signup function
  const signup = async (name: string, email: string, password: string) => {
    setIsLoading(true)
    try {
      // Create user with email and password
      const userCredential = await createUserWithEmailAndPassword(auth, email, password)
      const firebaseUser = userCredential.user

      // Generate a username from the email
      const username = email
        .split("@")[0]
        .toLowerCase()
        .replace(/[^a-z0-9]/g, "")

      // Update profile with name
      await updateProfile(firebaseUser, { displayName: name })

      // Store additional user data in Firestore
      await setDoc(doc(db, "users", firebaseUser.uid), {
        name,
        email,
        username,
        createdAt: serverTimestamp(),
        streakCount: 0,
        completedHabits: 0,
      })

      // Wait a moment for auth state to update
      await new Promise((resolve) => setTimeout(resolve, 500))

      // Navigate to dashboard
      router.push("/dashboard")
      router.refresh()
    } catch (error) {
      console.error("Signup failed:", error)
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  // Logout function
  const logout = async () => {
    try {
      await signOut(auth)
      router.push("/login")
      router.refresh()
    } catch (error) {
      console.error("Logout failed:", error)
      throw error
    }
  }

  // Update user profile
  const updateUserProfile = async (data: Partial<User>) => {
    if (!user) return

    try {
      // For demo purposes, we'll update the local state immediately
      // and also try to update Firestore if available

      // Update local state first
      setUser((prev) => (prev ? { ...prev, ...data } : null))

      // Try to update Firestore document (will fail gracefully if not configured)
      try {
        await setDoc(doc(db, "users", user.id), data, { merge: true })
      } catch (firestoreError) {
        console.log("Firestore update skipped (demo mode):", firestoreError)
      }

      // Update Firebase Auth profile if name is provided
      if (data.name && auth.currentUser) {
        try {
          await updateProfile(auth.currentUser, { displayName: data.name })
        } catch (authError) {
          console.log("Auth profile update skipped (demo mode):", authError)
        }
      }
    } catch (error) {
      console.error("Profile update failed:", error)
      throw error
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        login,
        signup,
        logout,
        updateUserProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
