import { initializeApp } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getFirestore } from "firebase/firestore"
import { getStorage } from "firebase/storage"

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCm0G9AMlEYHgOjDttmByvBdIyCg6-YVwI",
  authDomain: "habit-tracker-47b0b.firebaseapp.com",
  projectId: "habit-tracker-47b0b",
  storageBucket: "habit-tracker-47b0b.firebasestorage.app",
  messagingSenderId: "63299090258",
  appId: "1:63299090258:web:2dcd44a83935cad7476c8b",
  measurementId: "G-EJVZ8C7060"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig)
export const auth = getAuth(app)
export const db = getFirestore(app)
export const storage = getStorage(app)

export default app
