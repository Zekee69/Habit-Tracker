"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { CheckCircle2, XCircle, Share2 } from "lucide-react"

type Habit = {
  id: string
  name: string
  category: string
  completed: boolean
  streak?: number
}

interface HabitListProps {
  onShareStreak?: (habitName: string, streakCount: number) => void
}

export function HabitList({ onShareStreak }: HabitListProps) {
  const [habits, setHabits] = useState<Habit[]>([
    { id: "1", name: "Morning Run", category: "Fitness", completed: false, streak: 5 },
    { id: "2", name: "Read 30 minutes", category: "Learning", completed: true, streak: 12 },
    { id: "3", name: "Meditate", category: "Mindfulness", completed: false, streak: 3 },
    { id: "4", name: "Drink 8 glasses of water", category: "Nutrition", completed: false, streak: 7 },
  ])

  const toggleHabit = (id: string) => {
    setHabits(habits.map((habit) => (habit.id === id ? { ...habit, completed: !habit.completed } : habit)))
  }

  return (
    <div className="space-y-4">
      {habits.map((habit) => (
        <div
          key={habit.id}
          className={`flex items-center justify-between p-4 border rounded-lg ${
            habit.completed ? "bg-emerald-50 border-emerald-200" : ""
          }`}
        >
          <div>
            <h3 className="font-medium">{habit.name}</h3>
            <div className="flex items-center gap-2">
              <p className="text-sm text-gray-500">{habit.category}</p>
              {habit.streak && habit.streak > 0 && (
                <span className="text-xs font-medium text-emerald-500">{habit.streak} day streak</span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            {habit.streak && habit.streak > 0 && onShareStreak && (
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-500"
                onClick={() => onShareStreak(habit.name, habit.streak!)}
              >
                <Share2 className="h-4 w-4" />
              </Button>
            )}
            <Button
              variant={habit.completed ? "default" : "outline"}
              size="sm"
              className={habit.completed ? "bg-emerald-500 hover:bg-emerald-600" : ""}
              onClick={() => toggleHabit(habit.id)}
            >
              <CheckCircle2 className="h-4 w-4 mr-2" />
              {habit.completed ? "Completed" : "Mark Complete"}
            </Button>
            {!habit.completed && (
              <Button
                variant="outline"
                size="sm"
                className="border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600"
                onClick={() => toggleHabit(habit.id)}
              >
                <XCircle className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}
