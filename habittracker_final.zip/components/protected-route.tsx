"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"

export function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth()
  const router = useRouter()
  const pathname = usePathname()
  const [isCheckingAuth, setIsCheckingAuth] = useState(true)

  useEffect(() => {
    // Skip redirect for auth pages
    if (pathname === "/login" || pathname === "/signup") {
      setIsCheckingAuth(false)
      return
    }

    if (!isLoading) {
      if (!isAuthenticated) {
        // Only redirect to login if not already on an auth page
        router.push("/login")
      }
      setIsCheckingAuth(false)
    }
  }, [isAuthenticated, isLoading, router, pathname])

  if (isLoading || isCheckingAuth) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="h-16 w-16 animate-spin rounded-full border-4 border-solid border-purple-500 border-t-transparent"></div>
      </div>
    )
  }

  // Allow rendering on auth pages even when not authenticated
  if (!isAuthenticated && pathname !== "/login" && pathname !== "/signup") {
    return null
  }

  return <>{children}</>
}
