import { Award, Check, Clock } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import type { Achievement } from "@/types/achievement"

interface AchievementCardProps {
  achievement: Achievement
}

export function AchievementCard({ achievement }: AchievementCardProps) {
  const progress = Math.round((achievement.progress.current / achievement.progress.target) * 100)

  const getIcon = () => {
    switch (achievement.icon) {
      case "award":
        return <Award className="h-5 w-5" />
      case "check":
        return <Check className="h-5 w-5" />
      case "clock":
        return <Clock className="h-5 w-5" />
      default:
        return <Award className="h-5 w-5" />
    }
  }

  return (
    <Card className={`border ${achievement.earned ? "border-purple-200 bg-purple-50" : "border-gray-200"}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div
            className={`p-2 rounded-full ${
              achievement.earned ? "bg-purple-100 text-purple-500" : "bg-gray-100 text-gray-400"
            }`}
          >
            {getIcon()}
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">{achievement.title}</h3>
              {achievement.earned && (
                <span className="text-xs font-medium text-purple-500 bg-purple-100 px-2 py-1 rounded-full">Earned</span>
              )}
            </div>
            <p className="text-sm text-gray-500 mt-1">{achievement.description}</p>
            <div className="mt-2">
              <div className="flex items-center justify-between text-xs mb-1">
                <span>Progress</span>
                <span>
                  {achievement.progress.current}/{achievement.progress.target}
                </span>
              </div>
              <Progress value={progress} className="h-1.5" />
            </div>
            {achievement.earnedDate && <p className="text-xs text-gray-400 mt-2">Earned on {achievement.earnedDate}</p>}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
