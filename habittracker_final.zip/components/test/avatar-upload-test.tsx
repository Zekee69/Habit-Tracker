"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AvatarUpload } from "@/components/profile/avatar-upload"
import { useAvatar } from "@/hooks/use-avatar"
import { toast } from "@/components/ui/use-toast"
import { Upload, FileImage, AlertCircle, CheckCircle } from "lucide-react"

interface TestResult {
  fileName: string
  fileSize: string
  fileType: string
  status: "success" | "error" | "pending"
  message: string
  timestamp: Date
}

export function AvatarUploadTest() {
  const { avatarUrl, removeAvatar } = useAvatar()
  const [testResults, setTestResults] = useState<TestResult[]>([])
  const [isTestMode, setIsTestMode] = useState(false)

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const testFileUpload = async (file: File) => {
    const testResult: TestResult = {
      fileName: file.name,
      fileSize: formatFileSize(file.size),
      fileType: file.type,
      status: "pending",
      message: "Testing...",
      timestamp: new Date(),
    }

    setTestResults((prev) => [testResult, ...prev])

    try {
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        throw new Error("File size exceeds 5MB limit")
      }

      // Validate file type
      if (!file.type.startsWith("image/")) {
        throw new Error("File is not an image")
      }

      const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "image/gif", "image/webp"]
      if (!allowedTypes.includes(file.type)) {
        throw new Error("Unsupported image format")
      }

      // Test file reading
      const reader = new FileReader()
      await new Promise((resolve, reject) => {
        reader.onload = resolve
        reader.onerror = reject
        reader.readAsDataURL(file)
      })

      // Update test result
      setTestResults((prev) =>
        prev.map((result) =>
          result.timestamp === testResult.timestamp
            ? { ...result, status: "success", message: "Upload successful" }
            : result,
        ),
      )

      toast({
        title: "Test successful",
        description: `${file.name} can be uploaded successfully`,
      })
    } catch (error: any) {
      setTestResults((prev) =>
        prev.map((result) =>
          result.timestamp === testResult.timestamp ? { ...result, status: "error", message: error.message } : result,
        ),
      )

      toast({
        title: "Test failed",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const handleTestFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    Array.from(files).forEach((file) => {
      testFileUpload(file)
    })

    // Reset input
    e.target.value = ""
  }

  const clearTestResults = () => {
    setTestResults([])
  }

  const generateTestFiles = () => {
    const testCases = [
      { name: "Small JPEG", size: "< 100KB", format: "JPEG", expected: "✅ Should work" },
      { name: "Medium PNG", size: "100KB - 1MB", format: "PNG", expected: "✅ Should work" },
      { name: "Large GIF", size: "1MB - 5MB", format: "GIF", expected: "✅ Should work" },
      { name: "WebP Image", size: "Any size < 5MB", format: "WebP", expected: "✅ Should work" },
      { name: "Very Large Image", size: "> 5MB", format: "Any", expected: "❌ Should fail" },
      { name: "Non-image file", size: "Any", format: "PDF/DOC/etc", expected: "❌ Should fail" },
      { name: "Unsupported format", size: "Any", format: "BMP/TIFF", expected: "❌ Should fail" },
    ]

    return testCases
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileImage className="h-5 w-5" />
            Avatar Upload Testing
          </CardTitle>
          <CardDescription>Test different image formats and sizes for profile picture upload</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <AvatarUpload />
            <div className="space-y-2">
              <p className="text-sm font-medium">Current Avatar Status:</p>
              <Badge variant={avatarUrl ? "default" : "secondary"}>{avatarUrl ? "Avatar Set" : "No Avatar"}</Badge>
              {avatarUrl && (
                <Button variant="outline" size="sm" onClick={removeAvatar}>
                  Remove Avatar
                </Button>
              )}
            </div>
          </div>

          <div className="border-t pt-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Test File Upload</h3>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={clearTestResults}>
                  Clear Results
                </Button>
                <label htmlFor="test-files">
                  <Button size="sm" asChild>
                    <span>
                      <Upload className="mr-2 h-4 w-4" />
                      Test Files
                    </span>
                  </Button>
                </label>
              </div>
            </div>

            <input id="test-files" type="file" multiple accept="*/*" className="hidden" onChange={handleTestFiles} />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Expected Test Cases</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {generateTestFiles().map((testCase, index) => (
                    <div key={index} className="flex justify-between items-center text-sm">
                      <div>
                        <span className="font-medium">{testCase.name}</span>
                        <span className="text-gray-500 ml-2">({testCase.format})</span>
                      </div>
                      <span className="text-xs">{testCase.expected}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Upload Specifications</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Max file size:</span>
                    <span className="font-medium">5MB</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Supported formats:</span>
                    <span className="font-medium">JPEG, PNG, GIF, WebP</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Storage:</span>
                    <span className="font-medium">localStorage (demo)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Validation:</span>
                    <span className="font-medium">Client-side</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {testResults.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Test Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {testResults.map((result, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          {result.status === "success" ? (
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          ) : result.status === "error" ? (
                            <AlertCircle className="h-4 w-4 text-red-500" />
                          ) : (
                            <div className="h-4 w-4 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin" />
                          )}
                          <div>
                            <p className="font-medium text-sm">{result.fileName}</p>
                            <p className="text-xs text-gray-500">
                              {result.fileType} • {result.fileSize}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge
                            variant={
                              result.status === "success"
                                ? "default"
                                : result.status === "error"
                                  ? "destructive"
                                  : "secondary"
                            }
                          >
                            {result.status}
                          </Badge>
                          <p className="text-xs text-gray-500 mt-1">{result.message}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
