"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart } from "lucide-react"

interface CompletionRateChartProps {
  completedPercentage: number
  previousPercentage: number
}

export function CompletionRateChart({ completedPercentage, previousPercentage }: CompletionRateChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const percentageChange = completedPercentage - previousPercentage

  useEffect(() => {
    if (!canvasRef.current) return

    const ctx = canvasRef.current.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const canvas = canvasRef.current
    canvas.width = canvas.offsetWidth
    canvas.height = canvas.offsetWidth // Make it square

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Chart settings
    const centerX = canvas.width / 2
    const centerY = canvas.height / 2
    const radius = Math.min(centerX, centerY) * 0.8

    // Draw background circle
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
    ctx.fillStyle = "#f3f4f6" // gray-100
    ctx.fill()

    // Draw completion arc
    const startAngle = -Math.PI / 2 // Start from the top
    const endAngle = startAngle + (Math.PI * 2 * completedPercentage) / 100

    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, startAngle, endAngle)
    ctx.lineTo(centerX, centerY)
    ctx.closePath()
    ctx.fillStyle = "#8b5cf6" // purple-500
    ctx.fill()

    // Draw inner circle (donut hole)
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius * 0.6, 0, Math.PI * 2)
    ctx.fillStyle = "#ffffff" // white
    ctx.fill()

    // Draw text in the center
    ctx.fillStyle = "#111827" // gray-900
    ctx.font = "bold 24px sans-serif"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(`${Math.round(completedPercentage)}%`, centerX, centerY - 10)

    // Draw label
    ctx.fillStyle = "#6b7280" // gray-500
    ctx.font = "14px sans-serif"
    ctx.fillText("Completion Rate", centerX, centerY + 15)
  }, [completedPercentage])

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <PieChart className="mr-2 h-5 w-5 text-purple-500" />
            Habit Completion Rate
          </div>
          <div className={`text-sm font-medium ${percentageChange >= 0 ? "text-emerald-500" : "text-red-500"}`}>
            {percentageChange >= 0 ? "+" : ""}
            {percentageChange.toFixed(1)}%
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex justify-center">
        <div className="w-[200px] h-[200px]">
          <canvas ref={canvasRef} className="w-full h-full"></canvas>
        </div>
      </CardContent>
    </Card>
  )
}
