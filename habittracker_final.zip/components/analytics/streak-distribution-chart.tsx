"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer } from "recharts"
import { TrendingUp } from "lucide-react"

interface StreakDistributionData {
  habitName: string
  streak: number
}

interface StreakDistributionChartProps {
  data: StreakDistributionData[]
}

export function StreakDistributionChart({ data }: StreakDistributionChartProps) {
  // If no data, show placeholder
  if (!data || data.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center text-sm font-medium">
            <TrendingUp className="mr-2 h-4 w-4 text-purple-500" />
            Streak Distribution
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[200px] flex items-center justify-center text-gray-500 text-sm">
            No streak data available
          </div>
        </CardContent>
      </Card>
    )
  }

  // Sort data by streak length for better visualization
  const sortedData = [...data].sort((a, b) => b.streak - a.streak)

  // Truncate habit names if too long
  const chartData = sortedData.map((item) => ({
    ...item,
    displayName: item.habitName.length > 12 ? item.habitName.substring(0, 12) + "..." : item.habitName,
  }))

  const maxStreak = Math.max(...data.map((d) => d.streak))

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center text-sm font-medium">
          <TrendingUp className="mr-2 h-4 w-4 text-purple-500" />
          Streak Distribution
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer
          config={{
            streak: {
              label: "Streak Days",
              color: "hsl(var(--chart-1))",
            },
          }}
          className="h-[200px]"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
              <XAxis
                dataKey="displayName"
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 10, fill: "#6b7280" }}
                interval={0}
                angle={-45}
                textAnchor="end"
                height={60}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 10, fill: "#6b7280" }}
                domain={[0, maxStreak + 1]}
              />
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    formatter={(value, name, props) => [`${value} days`, props.payload?.habitName || name]}
                  />
                }
              />
              <Bar dataKey="streak" fill="#8b5cf6" radius={[2, 2, 0, 0]} maxBarSize={40} />
            </BarChart>
          </ResponsiveContainer>
        </ChartContainer>
        <div className="mt-3 text-xs text-gray-500 text-center">Showing current streaks for all habits</div>
      </CardContent>
    </Card>
  )
}
