"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp } from "lucide-react"

type HabitGrowthData = {
  month: string
  count: number
}

interface HabitGrowthChartProps {
  data: HabitGrowthData[]
  percentageChange: number
}

export function HabitGrowthChart({ data, percentageChange }: HabitGrowthChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const ctx = canvasRef.current.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const canvas = canvasRef.current
    canvas.width = canvas.offsetWidth
    canvas.height = 300

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Chart settings
    const padding = 40
    const chartWidth = canvas.width - padding * 2
    const chartHeight = canvas.height - padding * 2
    const maxValue = Math.max(...data.map((item) => item.count)) * 1.2 // Add 20% padding at the top

    // Draw line chart
    ctx.strokeStyle = "#8b5cf6" // purple-500
    ctx.lineWidth = 3
    ctx.beginPath()

    data.forEach((item, index) => {
      const x = padding + (index / (data.length - 1)) * chartWidth
      const y = canvas.height - padding - (item.count / maxValue) * chartHeight

      if (index === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }

      // Draw point
      ctx.fillStyle = "#8b5cf6"
      ctx.beginPath()
      ctx.arc(x, y, 5, 0, Math.PI * 2)
      ctx.fill()
    })

    ctx.stroke()

    // Fill area under the line
    ctx.beginPath()
    data.forEach((item, index) => {
      const x = padding + (index / (data.length - 1)) * chartWidth
      const y = canvas.height - padding - (item.count / maxValue) * chartHeight

      if (index === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    })
    ctx.lineTo(padding + chartWidth, canvas.height - padding)
    ctx.lineTo(padding, canvas.height - padding)
    ctx.closePath()
    ctx.fillStyle = "rgba(139, 92, 246, 0.1)" // purple-500 with opacity
    ctx.fill()

    // Draw axes
    ctx.strokeStyle = "#e5e7eb" // gray-200
    ctx.lineWidth = 1

    // X-axis
    ctx.beginPath()
    ctx.moveTo(padding, canvas.height - padding)
    ctx.lineTo(canvas.width - padding, canvas.height - padding)
    ctx.stroke()

    // Y-axis
    ctx.beginPath()
    ctx.moveTo(padding, padding)
    ctx.lineTo(padding, canvas.height - padding)
    ctx.stroke()

    // Draw labels
    ctx.fillStyle = "#374151" // gray-700
    ctx.font = "12px sans-serif"
    ctx.textAlign = "center"

    data.forEach((item, index) => {
      const x = padding + (index / (data.length - 1)) * chartWidth
      ctx.fillText(item.month, x, canvas.height - padding + 20)
    })

    // Draw Y-axis labels
    ctx.textAlign = "right"
    const ySteps = 5
    for (let i = 0; i <= ySteps; i++) {
      const value = Math.round((maxValue * i) / ySteps)
      const y = canvas.height - padding - (i / ySteps) * chartHeight
      ctx.fillText(value.toString(), padding - 10, y + 5)
    }
  }, [data])

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <TrendingUp className="mr-2 h-5 w-5 text-purple-500" />
            Habit Growth Over Time
          </div>
          <div className={`text-sm font-medium ${percentageChange >= 0 ? "text-emerald-500" : "text-red-500"}`}>
            {percentageChange >= 0 ? "+" : ""}
            {percentageChange}%
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] w-full">
          <canvas ref={canvasRef} className="w-full h-full"></canvas>
        </div>
      </CardContent>
    </Card>
  )
}
