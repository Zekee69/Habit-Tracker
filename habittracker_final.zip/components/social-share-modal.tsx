"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { CheckCircle, Copy, Share2, Twitter, Facebook, Linkedin, Mail } from "lucide-react"

interface SocialShareModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  achievement?: {
    title: string
    description: string
  }
  habitName?: string
  streakCount?: number
}

export function SocialShareModal({ open, onOpenChange, achievement, habitName, streakCount }: SocialShareModalProps) {
  const [copied, setCopied] = useState(false)

  const shareUrl = "https://habittracker.app/profile/johndoe"

  const getShareText = () => {
    if (achievement) {
      return `I just earned the "${achievement.title}" achievement on HabitTracker! ${shareUrl}`
    } else if (habitName && streakCount) {
      return `I'm on a ${streakCount}-day streak for "${habitName}" on HabitTracker! ${shareUrl}`
    } else if (streakCount) {
      return `I'm on a ${streakCount}-day streak on HabitTracker! ${shareUrl}`
    } else {
      return `Check out my progress on HabitTracker! ${shareUrl}`
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(getShareText())
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const shareToTwitter = () => {
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(getShareText())}`, "_blank")
  }

  const shareToFacebook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, "_blank")
  }

  const shareToLinkedIn = () => {
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`, "_blank")
  }

  const shareByEmail = () => {
    window.open(
      `mailto:?subject=Check out my progress on HabitTracker&body=${encodeURIComponent(getShareText())}`,
      "_blank",
    )
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Share2 className="mr-2 h-5 w-5" />
            Share Your Progress
          </DialogTitle>
          <DialogDescription>
            {achievement
              ? "Share your achievement with friends and followers"
              : "Share your habit streak with friends and followers"}
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="social" className="w-full">
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="social">Social Media</TabsTrigger>
            <TabsTrigger value="link">Copy Link</TabsTrigger>
          </TabsList>

          <TabsContent value="social" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Button
                variant="outline"
                className="flex items-center justify-center gap-2 h-12"
                onClick={shareToTwitter}
              >
                <Twitter className="h-5 w-5 text-[#1DA1F2]" />
                Twitter
              </Button>
              <Button
                variant="outline"
                className="flex items-center justify-center gap-2 h-12"
                onClick={shareToFacebook}
              >
                <Facebook className="h-5 w-5 text-[#4267B2]" />
                Facebook
              </Button>
              <Button
                variant="outline"
                className="flex items-center justify-center gap-2 h-12"
                onClick={shareToLinkedIn}
              >
                <Linkedin className="h-5 w-5 text-[#0A66C2]" />
                LinkedIn
              </Button>
              <Button variant="outline" className="flex items-center justify-center gap-2 h-12" onClick={shareByEmail}>
                <Mail className="h-5 w-5 text-gray-600" />
                Email
              </Button>
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium">Customize your message</p>
              <Textarea defaultValue={getShareText()} rows={3} />
            </div>
          </TabsContent>

          <TabsContent value="link" className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm font-medium">Share this link with others</p>
              <div className="flex items-center gap-2">
                <Input value={shareUrl} readOnly />
                <Button variant="outline" size="icon" onClick={copyToClipboard} className="flex-shrink-0">
                  {copied ? <CheckCircle className="h-4 w-4 text-purple-500" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium">Or share this message</p>
              <div className="flex items-center gap-2">
                <Input value={getShareText()} readOnly />
                <Button variant="outline" size="icon" onClick={copyToClipboard} className="flex-shrink-0">
                  {copied ? <CheckCircle className="h-4 w-4 text-purple-500" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter className="sm:justify-start">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button className="bg-purple-500 hover:bg-purple-600" onClick={() => onOpenChange(false)}>
            Done
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
