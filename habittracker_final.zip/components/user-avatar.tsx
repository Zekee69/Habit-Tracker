"use client"

import { useState, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/contexts/auth-context"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { LogOut, Settings, User } from "lucide-react"
import Link from "next/link"

export function UserAvatar() {
  const { user, logout } = useAuth()
  const [isOpen, setIsOpen] = useState(false)
  const [currentAvatar, setCurrentAvatar] = useState<string | null>(null)

  // Load current avatar
  useEffect(() => {
    const savedAvatar = localStorage.getItem("user_avatar")
    if (savedAvatar) {
      setCurrentAvatar(savedAvatar)
    } else if (user?.avatar) {
      setCurrentAvatar(user.avatar)
    }
  }, [user])

  // Listen for avatar changes
  useEffect(() => {
    const handleStorageChange = () => {
      const savedAvatar = localStorage.getItem("user_avatar")
      setCurrentAvatar(savedAvatar)
    }

    window.addEventListener("storage", handleStorageChange)

    // Also check periodically for changes within the same tab
    const interval = setInterval(handleStorageChange, 1000)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      clearInterval(interval)
    }
  }, [])

  if (!user) return null

  const getAvatarUrl = () => {
    return currentAvatar || "/placeholder.svg?height=36&width=36"
  }

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <button className="focus:outline-none">
          <Avatar className="h-9 w-9 cursor-pointer border-2 border-purple-100">
            <AvatarImage src={getAvatarUrl() || "/placeholder.svg"} alt={user.name} className="object-cover" />
            <AvatarFallback className="bg-purple-100 text-purple-700">
              {user.name.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>
          <div className="flex flex-col">
            <span>{user.name}</span>
            <span className="text-xs text-gray-500">{user.email}</span>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <Link href="/profile">
          <DropdownMenuItem className="cursor-pointer">
            <User className="mr-2 h-4 w-4" />
            <span>Profile</span>
          </DropdownMenuItem>
        </Link>
        <Link href="/settings">
          <DropdownMenuItem className="cursor-pointer">
            <Settings className="mr-2 h-4 w-4" />
            <span>Settings</span>
          </DropdownMenuItem>
        </Link>
        <DropdownMenuSeparator />
        <DropdownMenuItem className="cursor-pointer" onClick={logout}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
