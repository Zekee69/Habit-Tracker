"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"

export function HabitChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const ctx = canvasRef.current.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const canvas = canvasRef.current
    canvas.width = canvas.offsetWidth
    canvas.height = 300

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Data for the chart
    const habits = [
      { name: "Morning Run", completion: 0.71 },
      { name: "Read 30 minutes", completion: 0.85 },
      { name: "Meditate", completion: 0.6 },
      { name: "Drink 8 glasses of water", completion: 1.0 },
    ]

    // Chart settings
    const padding = 40
    const barWidth = (canvas.width - padding * 2) / habits.length - 20
    const maxBarHeight = canvas.height - padding * 2

    // Draw bars
    habits.forEach((habit, index) => {
      const x = padding + index * (barWidth + 20)
      const barHeight = maxBarHeight * habit.completion
      const y = canvas.height - padding - barHeight

      // Draw bar
      ctx.fillStyle = "#8b5cf6" // purple-500
      ctx.fillRect(x, y, barWidth, barHeight)

      // Draw label
      ctx.fillStyle = "#374151" // gray-700
      ctx.font = "12px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(habit.name, x + barWidth / 2, canvas.height - padding + 20)

      // Draw percentage
      ctx.fillStyle = "#8b5cf6" // purple-500
      ctx.font = "bold 14px sans-serif"
      ctx.fillText(`${Math.round(habit.completion * 100)}%`, x + barWidth / 2, y - 10)
    })

    // Draw axes
    ctx.strokeStyle = "#e5e7eb" // gray-200
    ctx.lineWidth = 1

    // X-axis
    ctx.beginPath()
    ctx.moveTo(padding, canvas.height - padding)
    ctx.lineTo(canvas.width - padding, canvas.height - padding)
    ctx.stroke()

    // Y-axis
    ctx.beginPath()
    ctx.moveTo(padding, padding)
    ctx.lineTo(padding, canvas.height - padding)
    ctx.stroke()
  }, [])

  return (
    <div className="space-y-6">
      <div className="h-[300px] w-full">
        <canvas ref={canvasRef} className="w-full h-full"></canvas>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardContent className="pt-6">
            <h3 className="font-medium mb-2">Weekly Completion Rate</h3>
            <div className="text-3xl font-bold text-purple-500">79%</div>
            <p className="text-sm text-gray-500 mt-1">+12% from last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <h3 className="font-medium mb-2">Current Streak</h3>
            <div className="text-3xl font-bold text-purple-500">12 days</div>
            <p className="text-sm text-gray-500 mt-1">Reading habit</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
