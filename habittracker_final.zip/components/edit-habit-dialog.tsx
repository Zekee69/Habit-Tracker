"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Habit } from "@/types/habit"
import { Clock } from "lucide-react"

interface EditHabitDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  habit: Habit | null
  onEditHabit: (habit: Habit) => void
}

export function EditHabitDialog({ open, onOpenChange, habit, onEditHabit }: EditHabitDialogProps) {
  const [editedHabit, setEditedHabit] = useState<Habit | null>(habit)

  // Update local state when the habit prop changes
  useEffect(() => {
    setEditedHabit(habit)
  }, [habit])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editedHabit || !editedHabit.name) return

    onEditHabit(editedHabit)
  }

  if (!editedHabit) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Edit Habit</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-habit-name">Habit Name</Label>
              <Input
                id="edit-habit-name"
                value={editedHabit.name}
                onChange={(e) => setEditedHabit({ ...editedHabit, name: e.target.value })}
                placeholder="e.g., Morning Run"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-habit-category">Category</Label>
              <Select
                value={editedHabit.category}
                onValueChange={(value) => setEditedHabit({ ...editedHabit, category: value })}
              >
                <SelectTrigger id="edit-habit-category">
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Fitness">Fitness</SelectItem>
                  <SelectItem value="Nutrition">Nutrition</SelectItem>
                  <SelectItem value="Mindfulness">Mindfulness</SelectItem>
                  <SelectItem value="Learning">Learning</SelectItem>
                  <SelectItem value="Productivity">Productivity</SelectItem>
                  <SelectItem value="Social">Social</SelectItem>
                  <SelectItem value="Finance">Finance</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-habit-frequency">Frequency</Label>
              <Select
                value={editedHabit.frequency}
                onValueChange={(value) => setEditedHabit({ ...editedHabit, frequency: value })}
              >
                <SelectTrigger id="edit-habit-frequency">
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekdays">Weekdays</SelectItem>
                  <SelectItem value="weekends">Weekends</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-habit-start-time">Start Time (Optional)</Label>
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="edit-habit-start-time"
                  type="time"
                  value={editedHabit.startTime || ""}
                  onChange={(e) => setEditedHabit({ ...editedHabit, startTime: e.target.value })}
                  className="pl-10"
                  placeholder="Set start time for this habit"
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-habit-end-time">End Time (Optional)</Label>
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="edit-habit-end-time"
                  type="time"
                  value={editedHabit.endTime || ""}
                  onChange={(e) => setEditedHabit({ ...editedHabit, endTime: e.target.value })}
                  className="pl-10"
                  placeholder="Set end time for this habit"
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" className="bg-purple-500 hover:bg-purple-600">
              Save Changes
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
