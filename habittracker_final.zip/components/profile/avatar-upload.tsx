"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Slider } from "@/components/ui/slider"
import { Upload, X, Check, Camera } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

export function AvatarUpload() {
  const { user, updateUserProfile } = useAuth()
  const [isOpen, setIsOpen] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [currentAvatar, setCurrentAvatar] = useState<string | null>(null)
  const [zoom, setZoom] = useState([1])
  const [isUploading, setIsUploading] = useState(false)
  const [isDragOver, setIsDragOver] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Load current avatar on mount
  useEffect(() => {
    const savedAvatar = localStorage.getItem("user_avatar")
    if (savedAvatar) {
      setCurrentAvatar(savedAvatar)
    } else if (user?.avatar) {
      setCurrentAvatar(user.avatar)
    }
  }, [user])

  const validateFile = (file: File): string | null => {
    if (file.size > 5 * 1024 * 1024) {
      return "File size must be less than 5MB"
    }

    if (!file.type.startsWith("image/")) {
      return "Please select an image file"
    }

    const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "image/gif", "image/webp"]
    if (!allowedTypes.includes(file.type)) {
      return "Please select a JPEG, PNG, GIF, or WebP image"
    }

    return null
  }

  const processFile = (file: File) => {
    const validationError = validateFile(file)
    if (validationError) {
      toast({
        title: "Invalid file",
        description: validationError,
        variant: "destructive",
      })
      return
    }

    setSelectedFile(file)

    const reader = new FileReader()
    reader.onload = (e) => {
      const result = e.target?.result as string
      setPreviewUrl(result)
    }
    reader.onerror = () => {
      toast({
        title: "Error reading file",
        description: "There was a problem reading the selected file.",
        variant: "destructive",
      })
    }
    reader.readAsDataURL(file)
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      processFile(file)
    }
  }

  // Drag and drop handlers
  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragOver(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragOver(false)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragOver(false)

    const files = Array.from(e.dataTransfer.files)
    if (files.length > 0) {
      processFile(files[0])
    }
  }

  const handleUpload = async () => {
    if (!previewUrl) {
      toast({
        title: "No file selected",
        description: "Please select a file to upload.",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)

    try {
      // Simulate upload delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Save to localStorage
      localStorage.setItem("user_avatar", previewUrl)

      // Update current avatar state
      setCurrentAvatar(previewUrl)

      // Update user profile if function exists
      try {
        if (updateUserProfile) {
          await updateUserProfile({ avatar: previewUrl })
        }
      } catch (error) {
        console.log("Profile update skipped:", error)
      }

      toast({
        title: "Success!",
        description: "Your profile picture has been updated.",
      })

      // Close dialog and reset
      setIsOpen(false)
      handleCancel()
    } catch (error) {
      console.error("Upload error:", error)
      toast({
        title: "Upload failed",
        description: "There was a problem updating your profile picture.",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  const handleCancel = () => {
    setSelectedFile(null)
    setPreviewUrl(null)
    setZoom([1])
    setIsDragOver(false)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleDialogClose = (open: boolean) => {
    setIsOpen(open)
    if (!open) {
      handleCancel()
    }
  }

  const getDisplayAvatar = () => {
    return currentAvatar || "/placeholder.svg?height=96&width=96"
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleDialogClose}>
      <DialogTrigger asChild>
        <div className="relative group cursor-pointer">
          <Avatar className="h-24 w-24 border-2 border-white shadow-lg">
            <AvatarImage
              src={getDisplayAvatar() || "/placeholder.svg"}
              alt={user?.name || "User"}
              className="object-cover"
            />
            <AvatarFallback className="text-lg font-semibold bg-purple-100 text-purple-700">
              {user?.name?.charAt(0)?.toUpperCase() || "U"}
            </AvatarFallback>
          </Avatar>
          <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <Camera className="h-6 w-6 text-white" />
          </div>
        </div>
      </DialogTrigger>

      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Update Profile Picture</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {!previewUrl ? (
            <div className="space-y-4">
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all duration-200 ${
                  isDragOver
                    ? "border-purple-500 bg-purple-50 scale-105"
                    : "border-gray-300 hover:bg-gray-50 hover:border-gray-400"
                }`}
                onClick={() => fileInputRef.current?.click()}
                onDragEnter={handleDragEnter}
                onDragLeave={handleDragLeave}
                onDragOver={handleDragOver}
                onDrop={handleDrop}
              >
                <Upload
                  className={`h-8 w-8 mx-auto mb-4 transition-colors ${
                    isDragOver ? "text-purple-500" : "text-gray-400"
                  }`}
                />
                <p
                  className={`text-sm font-medium transition-colors ${
                    isDragOver ? "text-purple-700" : "text-gray-600"
                  }`}
                >
                  {isDragOver ? "Drop your image here" : "Click to upload or drag and drop"}
                </p>
                <p className="text-xs text-gray-400 mt-1">PNG, JPG, GIF, or WebP (max. 5MB)</p>
                {isDragOver && (
                  <div className="mt-2">
                    <div className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-purple-100 text-purple-700">
                      Ready to upload
                    </div>
                  </div>
                )}
              </div>

              <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />

              <div className="flex items-center gap-4">
                <div className="flex-1 h-px bg-gray-200"></div>
                <span className="text-xs text-gray-500 font-medium">OR</span>
                <div className="flex-1 h-px bg-gray-200"></div>
              </div>

              <Button variant="outline" className="w-full" onClick={() => fileInputRef.current?.click()}>
                <Upload className="mr-2 h-4 w-4" />
                Choose File
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative w-48 h-48 mx-auto overflow-hidden rounded-full border-2 border-gray-200">
                <img
                  src={previewUrl || "/placeholder.svg"}
                  alt="Preview"
                  className="absolute w-full h-full object-cover transition-transform"
                  style={{ transform: `scale(${zoom[0]})` }}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Zoom</label>
                <Slider value={zoom} min={1} max={3} step={0.1} onValueChange={setZoom} className="w-full" />
                <div className="flex justify-between text-xs text-gray-500">
                  <span>1x</span>
                  <span>3x</span>
                </div>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" onClick={handleCancel} className="flex-1" disabled={isUploading}>
                  <X className="mr-2 h-4 w-4" />
                  Cancel
                </Button>
                <Button
                  onClick={handleUpload}
                  disabled={isUploading}
                  className="flex-1 bg-purple-500 hover:bg-purple-600"
                >
                  {isUploading ? (
                    <span className="flex items-center">
                      <div className="animate-spin -ml-1 mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                      Uploading...
                    </span>
                  ) : (
                    <>
                      <Check className="mr-2 h-4 w-4" />
                      Save
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
