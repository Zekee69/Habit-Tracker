export interface Habit {
  id: string
  name: string
  category: string
  frequency: string
  completed: boolean
  streak?: number
  startTime?: string // Start time in HH:MM format
  endTime?: string // End time in HH:MM format
}
