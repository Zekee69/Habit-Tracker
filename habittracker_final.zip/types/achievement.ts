export interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  earned: boolean
  earnedDate?: string
  progress: {
    current: number
    target: number
  }
  category: string
}
