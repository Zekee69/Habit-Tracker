"use client"

import { useState, useEffect, useRef } from "react"
import type { Achievement } from "@/types/achievement"
import type { Habit } from "@/types/habit"

export function useAchievements(habits: Habit[]) {
  const [achievements, setAchievements] = useState<Achievement[]>([
    {
      id: "1",
      title: "Early Bird",
      description: "Complete a habit before 8 AM for 5 consecutive days",
      icon: "clock",
      earned: false,
      progress: { current: 0, target: 5 },
      category: "consistency",
    },
    {
      id: "2",
      title: "Consistency King",
      description: "Maintain a 10-day streak",
      icon: "award",
      earned: false,
      progress: { current: 0, target: 10 },
      category: "consistency",
    },
    {
      id: "3",
      title: "Habit Master",
      description: "Complete all habits for 7 consecutive days",
      icon: "check",
      earned: false,
      progress: { current: 0, target: 7 },
      category: "consistency",
    },
    {
      id: "4",
      title: "Variety Pack",
      description: "Create habits in 5 different categories",
      icon: "award",
      earned: false,
      progress: { current: 0, target: 5 },
      category: "diversity",
    },
    {
      id: "5",
      title: "Fitness Fanatic",
      description: "Complete 20 fitness habits",
      icon: "award",
      earned: false,
      progress: { current: 0, target: 20 },
      category: "fitness",
    },
    {
      id: "6",
      title: "Mindfulness Guru",
      description: "Complete 15 mindfulness habits",
      icon: "award",
      earned: false,
      progress: { current: 0, target: 15 },
      category: "mindfulness",
    },
    {
      id: "7",
      title: "Learning Enthusiast",
      description: "Complete 15 learning habits",
      icon: "award",
      earned: false,
      progress: { current: 0, target: 15 },
      category: "learning",
    },
    {
      id: "8",
      title: "Nutrition Expert",
      description: "Complete 15 nutrition habits",
      icon: "award",
      earned: false,
      progress: { current: 0, target: 15 },
      category: "nutrition",
    },
    {
      id: "9",
      title: "Productivity Pro",
      description: "Complete 15 productivity habits",
      icon: "award",
      earned: false,
      progress: { current: 0, target: 15 },
      category: "productivity",
    },
    {
      id: "10",
      title: "Habit Creator",
      description: "Create 10 different habits",
      icon: "award",
      earned: false,
      progress: { current: 0, target: 10 },
      category: "general",
    },
    {
      id: "11",
      title: "Marathon Streak",
      description: "Maintain a 30-day streak on any habit",
      icon: "award",
      earned: false,
      progress: { current: 0, target: 30 },
      category: "consistency",
    },
    {
      id: "12",
      title: "Perfect Week",
      description: "Complete all habits for an entire week",
      icon: "check",
      earned: false,
      progress: { current: 0, target: 7 },
      category: "consistency",
    },
  ])

  // Use a ref to track if we've loaded from localStorage
  const hasLoadedFromStorage = useRef(false)

  // Load achievements from localStorage only once on initial render
  useEffect(() => {
    if (!hasLoadedFromStorage.current) {
      const storedAchievements = localStorage.getItem("achievements")
      if (storedAchievements) {
        setAchievements(JSON.parse(storedAchievements))
      }
      hasLoadedFromStorage.current = true
    }
  }, [])

  // Update achievements based on habits
  useEffect(() => {
    if (habits.length === 0 || !hasLoadedFromStorage.current) return

    // Create a new copy to avoid direct state mutation
    const updatedAchievements = [...achievements]

    // Check for "Consistency King" achievement
    const maxStreak = Math.max(...habits.map((habit) => habit.streak || 0))
    const consistencyKing = updatedAchievements.find((a) => a.id === "2")
    if (consistencyKing) {
      consistencyKing.progress = { current: Math.min(maxStreak, 10), target: 10 }
      if (maxStreak >= 10 && !consistencyKing.earned) {
        consistencyKing.earned = true
        consistencyKing.earnedDate = new Date().toLocaleDateString()
      }
    }

    // Check for "Marathon Streak" achievement
    const marathonStreak = updatedAchievements.find((a) => a.id === "11")
    if (marathonStreak) {
      marathonStreak.progress = { current: Math.min(maxStreak, 30), target: 30 }
      if (maxStreak >= 30 && !marathonStreak.earned) {
        marathonStreak.earned = true
        marathonStreak.earnedDate = new Date().toLocaleDateString()
      }
    }

    // Check for "Habit Creator" achievement
    const habitCreator = updatedAchievements.find((a) => a.id === "10")
    if (habitCreator) {
      habitCreator.progress = { current: Math.min(habits.length, 10), target: 10 }
      if (habits.length >= 10 && !habitCreator.earned) {
        habitCreator.earned = true
        habitCreator.earnedDate = new Date().toLocaleDateString()
      }
    }

    // Check for "Variety Pack" achievement
    const categories = new Set(habits.map((habit) => habit.category.toLowerCase()))
    const varietyPack = updatedAchievements.find((a) => a.id === "4")
    if (varietyPack) {
      varietyPack.progress = { current: Math.min(categories.size, 5), target: 5 }
      if (categories.size >= 5 && !varietyPack.earned) {
        varietyPack.earned = true
        varietyPack.earnedDate = new Date().toLocaleDateString()
      }
    }

    // Check for category-specific achievements
    const categoryAchievements = [
      { id: "5", category: "fitness" },
      { id: "6", category: "mindfulness" },
      { id: "7", category: "learning" },
      { id: "8", category: "nutrition" },
      { id: "9", category: "productivity" },
    ]

    categoryAchievements.forEach(({ id, category }) => {
      const completedInCategory = habits.filter(
        (habit) => habit.category.toLowerCase() === category && habit.completed,
      ).length

      const achievement = updatedAchievements.find((a) => a.id === id)
      if (achievement) {
        achievement.progress = { current: Math.min(completedInCategory, 15), target: 15 }
        if (completedInCategory >= 15 && !achievement.earned) {
          achievement.earned = true
          achievement.earnedDate = new Date().toLocaleDateString()
        }
      }
    })

    // Only update state if achievements have changed
    const achievementsChanged = JSON.stringify(updatedAchievements) !== JSON.stringify(achievements)
    if (achievementsChanged) {
      setAchievements(updatedAchievements)
      localStorage.setItem("achievements", JSON.stringify(updatedAchievements))
    }
  }, [habits, achievements])

  return { achievements }
}
