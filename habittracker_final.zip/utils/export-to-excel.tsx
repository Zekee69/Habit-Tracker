import * as XLSX from "xlsx"
import type { Habit } from "@/types/habit"

interface HabitStatistics {
  name: string
  category: string
  frequency: string
  streak: number
  completed: boolean
  completionRate?: string
}

export function exportHabitsToExcel(habits: Habit[], filename = "habit-statistics.xlsx") {
  // Calculate completion rate
  const totalHabits = habits.length
  const completedHabits = habits.filter((habit) => habit.completed).length
  const completionRate = totalHabits > 0 ? (completedHabits / totalHabits) * 100 : 0

  // Prepare data for export
  const habitsData: HabitStatistics[] = habits.map((habit) => ({
    name: habit.name,
    category: habit.category,
    frequency: habit.frequency,
    streak: habit.streak || 0,
    completed: habit.completed,
  }))

  // Add summary row
  habitsData.push({
    name: "TOTAL",
    category: "",
    frequency: "",
    streak: Math.max(...habits.map((h) => h.streak || 0)),
    completed: false,
    completionRate: `${completionRate.toFixed(1)}%`,
  })

  // Group by category
  const categoryCounts: Record<string, number> = {}
  habits.forEach((habit) => {
    const category = habit.category.toLowerCase()
    categoryCounts[category] = (categoryCounts[category] || 0) + 1
  })

  // Create category summary
  const categoryData = Object.entries(categoryCounts).map(([category, count]) => ({
    Category: category,
    Count: count,
    Percentage: `${((count / totalHabits) * 100).toFixed(1)}%`,
  }))

  // Create workbook with multiple sheets
  const wb = XLSX.utils.book_new()

  // Add habits sheet
  const habitsSheet = XLSX.utils.json_to_sheet(habitsData)
  XLSX.utils.book_append_sheet(wb, habitsSheet, "Habits")

  // Add categories sheet
  const categoriesSheet = XLSX.utils.json_to_sheet(categoryData)
  XLSX.utils.book_append_sheet(wb, categoriesSheet, "Categories")

  // Generate Excel file and trigger download
  XLSX.writeFile(wb, filename)
}
